baseurl= { 'url' : "http://10.1.33.16/" }

locators ={ 'username': '//*[@id="Username"]',

            'password' : '//*[@id="Password"]',

            'login_button' : '//*[@id="login-div"]/div[3]/div/input',

            'click_on_Summary' : '/html/body/ul/li[5]/a',

            'text' : '/html/body/div/div/h1',

            'text1' : '/html/body/div/div/form/label',

            'dropdowns':'//select[@id="Type"]',

            'Select_Summary' : '//*[@id="Type"]',

            'text2' : '/html/body/div/div/div/form/h3',

            'Generate_summary':'/html/body/div/div/div/form/div/button',
            'Joining_Year' : '//*[@id="EmpYear"]',
            'select_filter' : '//*[@id="EmpTypes"]',
            'Select_location':'//*[@id="EmpLocation"]',
            'Select_TCB': '//*[@id="EmpTCB"]',
            'popup': '//div[@id="myModal"]/div/div/div[3]/button',
            'TCB_TABLE' : '//th[contains(text(),"Month")]',
             'tableinfo':'//th[contains(text(),"Month")]'



}

joining_year={ '1999' : '//*[@id="EmpYear"]/option[2]',
               '2022' : '//*[@id="EmpYear"]/option[3]'

}
Select_filters={
    'Location' : '//*[@id="EmpTypes"]/option[2]',
}
Select_location={
    'Bengaluru': '//*[@id="EmpTypes"]/option[2]',
    'Kolkata':'//*[@id="EmpLocation"]/option[5]',
    'Pune' : '//*[@id="EmpLocation"]/option[6]',

}

pop_up={
    'popup1' :'//*[@id="lblModalValue"]/p',
    'popup2' : '//*[@id="lblModalValue"]/p',
    'popup3': '//*[@id="myModal"]'
}