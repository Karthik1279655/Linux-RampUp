import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
#from selenium.webdriver.chrome.service import Service
from selenium.webdriver.support.ui import Select
from Utilites.Akarsh_Locators import *


@pytest.mark.usefixtures('test_setup')
class Test:
    def popupbutton(self):
        try:
            close = self.driver.find_element(By.XPATH, locators['popup'])
            if close.text in self.driver.page_source:
                close.click()
                return True
        except:
            return False

    def tableinfo(self):
        try:
            table = self.driver.find_element(By.XPATH, locators["tableinfo"])
            if table.text in self.driver.page_source:
                return True
        except:
            return False


    #cheaking for summary is clikable or not
    def test_click_on_summary(self):
        self.driver.find_element(By.XPATH, locators['click_on_Summary']).click()
    #cheaking for The text 'Summary' is present at the top or not
    def test_text(self):
        text = self.driver.find_element(By.XPATH, locators['text']).text
        assert 'Summary' == text,"Summary is not matched "
    #cheaking Drop_down name summary type is matched or not
    def test_text1(self):
        text1 = self.driver.find_element(By.XPATH, locators['text1']).text
        assert 'Summary Type' == text1,"Summary type is not matched "
    #cheaking all dropdowns are prsent or not
    def test_dropdowns(self):
        drop_downs = Select(self.driver.find_element(By.XPATH, locators['dropdowns']))
        total = 4
        count = 0
        for i in drop_downs.options:
            count += 1
        assert total == count,"Not all drop downs are present "
    #selecting for FCA summary
    def test_select_FCA_Summary(self):
        summary_type = Select(self.driver.find_element(By.XPATH,locators['Select_Summary']))
        summary_type.select_by_index(1)
        print("FCA Summary is selected")

    def test_cheaking_Filter_is_present_or_not(self):
        summary_type = Select(self.driver.find_element(By.XPATH, locators['Select_Summary']))
        summary_type.select_by_index(1)
        text3 = self.driver.find_element(By.XPATH, locators['text2']).text
        assert text3 == 'Filters', 'Text does not match with Filters'
        print("Filter is present")

    def test_cheaking_without_filling_mandetory_DDB(self):
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() != True or Test().tableinfo()!= True
        print("Pop-up should come ")

    def test_selecting_All_location_for_1995(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(1)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(2)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo() == True
        print("Table or popup should be generated ")


    def test_selecting_Banglore_for_1995(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(1)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")



    def test_selecting_Kolkata_for_1995(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(1)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(2)
        assert Test().popupbutton() == True or Test.tableinfo() == True
        print(" Table or popup should be generated ")



    def test_selecting_ALL_location_for_1999(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(2)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(2)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")


    def test_selecting_Banglore_location_for_1999(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(2)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")


    def test_Selecting_kolkata_location_for_1999(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(2)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(4)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_selecting_Pune_location_for_1999(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(2)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton() == True or Test().tableinfo()== True
        print("Table or popup should be generated ")




    def test_selecting_All_location_for_2000(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(2)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")


    def test_selecting_Bengluru_location_for_2000(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")

    def test_selecting_Kolkata_location_for_2000(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(4)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")

    def test_selecting_Pune_location_for_2000(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")


    def test_selecting_All_location_for_2021(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(2)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")

    def test_selecting_Bengaluru_location_for_2021(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")


    def test_selecting_kolkata_location_for_2021(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(4)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")

    def test_selecting_Pune_location_for_2021(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        time.sleep(1)
        assert Test().popupbutton()== True or Test().tableinfo()== True
        print("Table or popup should be generated ")



    def test_selecting_All_location_for_2022(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(2)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")



    def test_selecting_Bengaluru_location_for_2022(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")

    def test_selecting_Kolkata_location_for_2022(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(4)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")

    def test_selecting_Pune_location_for_2022(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_filters = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_filters.select_by_index(1)
        select_location = Select(self.driver.find_element(By.XPATH, locators['Select_location']))
        select_location.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")



    def test_joining_2021_DOTNET(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH,locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_Filter = Select(self.driver.find_element(By.XPATH,locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH,locators['Select_TCB']))
        select_TCB.select_by_index(2)
        self.driver.find_element(By.XPATH,locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated  ")
    def test_Joining_2021_ALL(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(3)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert  Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joining_2021_TCB_AUTOMATION(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(4)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(5)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joiningYear_2022_TCB_AUTOMATION(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(5)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joiningYear_2022_TCB_Kernal(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(5)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(7)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert  Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joiningYear_2023_TCB_DOTNET(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(6)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(4)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")

    def test_joiningYear_2023_TCB_ALL(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(6)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(3)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joiningYear_2023_TCB_AUTOMATION(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(6)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(5)
        self.driver.find_element(By.XPATH, locators['Generate_summary']).click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated ")
    def test_joining_Year_2023_TCB_Android(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(6)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(4)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated")
    def test_JoiningYear_2023_TCB_KERnal(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(6)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(2)
        select_TCB = Select(self.driver.find_element(By.XPATH, locators['Select_TCB']))
        select_TCB.select_by_index(7)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or popup should be generated")

    def test_joiningYear_1995_select_filter_OverDue(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(1)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(3)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().popupbutton() == True or Test().tableinfo()== True
        print("Table or popup should be generated ")
    def test_joiningYear_2022_select_filter_OverDue(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(2)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(3)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert  Test().popupbutton() == True or Test().tableinfo() == True
        print("Table or pop up should be generated ")
    def test_joingYear_2023_selectingFilter_overDue(self):
        select_joining_year = Select(self.driver.find_element(By.XPATH, locators['Joining_Year']))
        select_joining_year.select_by_index(3)
        select_Filter = Select(self.driver.find_element(By.XPATH, locators['select_filter']))
        select_Filter.select_by_index(3)
        click_on_gs = self.driver.find_element(By.XPATH, locators['Generate_summary'])
        click_on_gs.click()
        assert Test().tableinfo() == True or Test().popupbutton() == True
        print("Table or popup should be generated")

































