locators1 ={'Summary': '//a[@href="/Home1/Summary"]',
           'Select_Summary' : '//*[@id="Type"]',
            'popup': '//div[@id="myModal"]/div/div/div[3]/button',
            'tableinfo':'//th[contains(text(),"Month")]',
           'summarycheck': '//h1[@style="text-align: center;"]',
           'overall': '//*[@id="Type"]',
           'filters': '//h3[@style="margin-top: 5%"]',
           'joiningbox': '//select[@id="EmpYear"]',
           'joining1999': '//select[@id="EmpYear"]/option[3]',
           'joining2022': '//select[@id="EmpYear"]/option[4]',
           'joining2023': '//select[@id="EmpYear"]/option[5]',
           'billedsearch': '//select[@id="EmpStatus"]',
            'billedyes': '//select[@id="EmpStatus"]/option[2]',
           'billedno': '//select[@id="EmpStatus"]/option[3]',
           'certifiedsearch': '//select[@id="EmpSEC"]',
           'certifiedyes': '//select[@id="EmpSEC"]/option[2]',
           'certifiedno': '//select[@id="EmpSEC"]/option[3]',
           'generate': '//button[@class="btn btn-primary"]',




        }