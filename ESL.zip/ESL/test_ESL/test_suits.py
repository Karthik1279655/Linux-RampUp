import time

import pytest
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from Utilities.locators import *

class Test():

    @pytest.fixture()
    def test_setup(self):
        global driver
        driver = webdriver.Chrome(executable_path='C:\\Users\\ee212668\\PycharmProjects\\drivers\\chromedriver.exe')
        baseurl = 'http://10.1.33.16/'
        driver.get(baseurl)
        driver.maximize_window()
        driver.implicitly_wait(10)
        time.sleep(2)

    @pytest.fixture()
    def test_login(self, test_setup):
        user_name = driver.find_element(By.ID, "Username")
        user_name.send_keys('Gururaj')

        password = driver.find_element(By.XPATH, '//input[@id="Password"]')
        password.send_keys('Gururaj!123')

        Login = driver.find_element(By.XPATH, '//div/input[@type="submit"]')
        Login.click()
        time.sleep(2)

    @pytest.fixture()
    def test_summary(self, test_setup, test_login):
        summary = driver.find_element(By.XPATH, locators1['Summary'])
        summary.click()

    def popupbutton(self):
        close = driver.find_element(By.XPATH, locators1['popup'])
        if close.text in driver.page_source:
            close.click()
            return True
        return False

    def tableinfo(self):
        table = driver.find_element(By.XPATH, locators1["tableinfo"])
        if table.text in driver.page_source:
            return True
        return False

    def test_summary_check(self, test_setup, test_login, test_summary):
        test_summary = driver.find_element(By.XPATH, locators1['summarycheck'])
        assert test_summary.text == 'Summary'
        time.sleep(2)

    def test_select_Overall_Summary(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)
        overallsummary = driver.find_element(By.XPATH, locators1['overall']).text
        if overallsummary in driver.page_source:
            assert True

    def test_filter(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)
        filters = driver.find_element(By.XPATH, locators1['filters']).text
        assert filters == "Filters"

    def test_joining_1999_billed_yes_certified_yes(self, test_setup, test_login, test_summary):
        time.sleep(2)
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining1999']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()
        assert Test().popupbutton() or Test().tableinfo()
        print("Joining 1999, billed yes, certified yes is verified")

    def test_joinig_1999_billed_yes_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining1999']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH,locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 1999, billed yes, certified no is verified")

    def test_joining1999_billed_no_certified_yes(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining1999']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()
        assert Test().popupbutton() or Test().tableinfo()
        print("Joining 1999, billed no, certified yes is verified")

    def test_joining_1999_billed_no_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining1999']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 1999, billed no, certified no is verified")

    def test_joining_2022_billed_yes_certified_yes(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2022']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2022, billed yes, certified yes is verified")

    def test_joining_2022_billed_yes_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2022']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2022, billed yes, certified no is verified")
#
    def test_joining_2022_billed_no_certified_yes(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2022']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().popupbutton() or Test().tableinfo()
        print("Joining 2022, billed no, certified yes is verified")

    def test_joining_2022_billed_no_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2022']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2022, billed no, certified no is verified")


    def test_joining_2023_billed_yes_certified_yes(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2023']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2023, billed yes, certified yes is verified")

    def test_joining_2023_billed_yes_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2023']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedyes']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        driver.find_element(By.XPATH, '//button[@class="btn btn-primary"]').click()
        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2023, billed yes, certified no is verified")


    def test_joining_2023_billed_no_certified_yes(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2023']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedyes']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2023, billed no, certified yes is verified")
#
    def test_joining_2023_billed_no_certified_no(self, test_setup, test_login, test_summary):
        summary_type = Select(driver.find_element(By.XPATH, locators1['Select_Summary']))
        summary_type.select_by_index(2)

        driver.find_element(By.XPATH, locators1['joiningbox']).click()
        driver.find_element(By.XPATH, locators1['joining2023']).click()

        driver.find_element(By.XPATH, locators1['billedsearch']).click()
        driver.find_element(By.XPATH, locators1['billedno']).click()

        driver.find_element(By.XPATH, locators1['certifiedsearch']).click()
        driver.find_element(By.XPATH, locators1['certifiedno']).click()

        driver.find_element(By.XPATH, locators1['generate']).click()

        assert Test().tableinfo() or Test().popupbutton()
        print("Joining 2023, billed no, certified no is verified")